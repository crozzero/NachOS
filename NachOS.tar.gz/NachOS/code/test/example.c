#include "syscall.h"
main() {
           int n;
           for (n=1;n<5;n++)
               Example(n);
